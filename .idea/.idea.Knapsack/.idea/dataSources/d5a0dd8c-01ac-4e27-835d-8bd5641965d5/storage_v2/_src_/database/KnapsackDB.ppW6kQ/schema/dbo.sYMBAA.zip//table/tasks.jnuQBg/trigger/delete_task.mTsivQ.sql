create   trigger delete_task
  on tasks after delete
  as
begin
  delete from det
  from details det
         inner join deleted del on det.TaskId = del.TaskId
  where del.TaskId = det.TaskId;
  delete from e
  from execution_processes e
         inner join deleted del on e.TaskId = del.TaskId
  where del.TaskId = e.TaskId;
  delete from ti
  from taskItem ti
         inner join deleted del on ti.TaskId = del.TaskId
  where del.TaskId = ti.TaskId;
end
go

