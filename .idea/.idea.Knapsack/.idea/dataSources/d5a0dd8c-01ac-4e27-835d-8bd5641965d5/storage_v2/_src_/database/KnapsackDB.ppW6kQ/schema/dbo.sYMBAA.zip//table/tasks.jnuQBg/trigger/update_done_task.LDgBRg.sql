create   trigger update_done_task
  on tasks after insert, update
  as
begin
  if update(PercentComplete)
    begin
      update tasks set status = 'done'
      from tasks inner join inserted on tasks.TaskId = inserted.TaskId
      where Inserted.PercentComplete = 100
    end
end
go

